
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AgentSharp.Core.Memory.Services.HNSW;
using AgentSharp.Core.Memory.Interfaces;
using AgentSharp.Core.Memory.Models;
using AgentSharp.Utils;

class TestHNSWProgram
{
    static async Task Main()
    {
        try
        {
            Console.WriteLine("🧠 Testing HNSW Memory Storage...");

            // Create a mock embedding service
            var embeddingService = new MockEmbeddingService();

            // Create compact HNSW configuration
            var config = CompactHNSWConfiguration.ForDevelopment();

            // Create compact HNSW storage
            var storage = new CompactHNSWMemoryStorage(embeddingService, config, new ConsoleLogger());

            // Initialize storage
            await storage.InitializeAsync();

            Console.WriteLine("✅ HNSW Storage initialized successfully!");

            // Add some test memories
            var memory1 = new UserMemory
            {
                Id = Guid.NewGuid().ToString(),
                UserId = "test-user",
                Content = "The cat sat on the mat",
                CreatedAt = DateTime.UtcNow
            };

            var memory2 = new UserMemory
            {
                Id = Guid.NewGuid().ToString(),
                UserId = "test-user",
                Content = "Dogs are loyal companions",
                CreatedAt = DateTime.UtcNow
            };

            Console.WriteLine("📝 Adding test memories...");
            await storage.AddMemoryAsync(memory1);
            await storage.AddMemoryAsync(memory2);

            Console.WriteLine("✅ Memories added successfully!");

            // Search for similar memories
            Console.WriteLine("🔍 Searching for similar content...");
            var results = await storage.SearchMemoriesAsync("pets and animals", "test-user", 10);

            Console.WriteLine($"📋 Found {results.Count} similar memories:");
            foreach (var result in results)
            {
                Console.WriteLine($"  - {result.Content} (Score: {result.RelevanceScore:F3})");
            }

            // Get compact HNSW metrics
            var metrics = storage.GetMetrics();
            Console.WriteLine($"📊 Compact HNSW Metrics:");
            Console.WriteLine($"  - Total Vectors: {metrics.TotalVectors}");
            Console.WriteLine($"  - Total Memories: {metrics.TotalMemories}");
            Console.WriteLine($"  - Total Inserts: {metrics.TotalInserts}");
            Console.WriteLine($"  - Total Searches: {metrics.TotalSearches}");
            Console.WriteLine($"  - Configured Dimensions: {metrics.ConfiguredDimensions}");
            Console.WriteLine($"  - Embedding Size: {metrics.EmbeddingSize}");
            Console.WriteLine($"  - Memory Usage: {metrics.EstimatedTotalMemoryUsage / 1024.0:F1} KB");
            Console.WriteLine($"  - Bytes per Vector: {metrics.EstimatedBytesPerVector}");
            Console.WriteLine($"  - Graph Connectivity: {metrics.GraphConnectivity}");
            Console.WriteLine($"  - Use Quantization: {metrics.UseQuantization}");
            Console.WriteLine($"  - Is Initialized: {metrics.IsInitialized}");

            Console.WriteLine("🎉 HNSW test completed successfully!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ Test failed: {ex.Message}");
            Console.WriteLine($"Stack trace: {ex.StackTrace}");
        }
    }
}

public class MockEmbeddingService : IEmbeddingService
{
    private Random _random = new Random(42); // Fixed seed for reproducible results

    public Task<List<float>> GenerateEmbeddingAsync(string text)
    {
        // Generate deterministic embeddings based on text hash
        var hash = text.GetHashCode();
        var random = new Random(hash);

        var embedding = new List<float>();
        for (int i = 0; i < 1536; i++) // OpenAI embedding size
        {
            embedding.Add((float)(random.NextDouble() * 2 - 1)); // Range [-1, 1]
        }

        return Task.FromResult(embedding);
    }

    public async Task<List<List<float>>> GenerateEmbeddingsAsync(List<string> texts)
    {
        var embeddings = new List<List<float>>();
        foreach (var text in texts)
        {
            embeddings.Add(await GenerateEmbeddingAsync(text));
        }
        return embeddings;
    }

    public double CalculateSimilarity(List<float> embedding1, List<float> embedding2)
    {
        if (embedding1?.Count != embedding2?.Count)
            return 0.0;

        double dotProduct = 0.0;
        double norm1 = 0.0;
        double norm2 = 0.0;

        for (int i = 0; i < embedding1.Count; i++)
        {
            dotProduct += embedding1[i] * embedding2[i];
            norm1 += embedding1[i] * embedding1[i];
            norm2 += embedding2[i] * embedding2[i];
        }

        if (norm1 == 0.0 || norm2 == 0.0)
            return 0.0;

        return dotProduct / (Math.Sqrt(norm1) * Math.Sqrt(norm2));
    }
}
